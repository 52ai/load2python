<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="fr">
<context>
    <name>HelpForm</name>
    <message>
        <location filename="helpform.py" line="24"/>
        <source>&amp;Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="helpform.py" line="27"/>
        <source>&amp;Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="helpform.py" line="29"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="helpform.py" line="53"/>
        <source>%1 Help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="imagechanger.pyw" line="58"/>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="60"/>
        <source>&amp;New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="60"/>
        <source>Create an image file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="63"/>
        <source>&amp;Open...</source>
        <translation>&amp;Ouvrez...</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="63"/>
        <source>Open an existing image file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="66"/>
        <source>&amp;Save</source>
        <translation>&amp;Sauvegardez</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="66"/>
        <source>Save the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="69"/>
        <source>Save &amp;As...</source>
        <translation>S&amp;auvegardez comme...</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="69"/>
        <source>Save the image using a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="72"/>
        <source>&amp;Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="72"/>
        <source>Print the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="75"/>
        <source>&amp;Quit</source>
        <translation>Stoppe&amp;z</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="75"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="75"/>
        <source>Close the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="78"/>
        <source>&amp;Invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="78"/>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="78"/>
        <source>Invert the image&apos;s colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="82"/>
        <source>Sw&amp;ap Red and Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="82"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="82"/>
        <source>Swap the image&apos;s red and blue color components</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="87"/>
        <source>&amp;Zoom...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="87"/>
        <source>Alt+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="148"/>
        <source>Zoom the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="90"/>
        <source>&amp;Resize...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="90"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="90"/>
        <source>Resize the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="94"/>
        <source>&amp;Unmirror</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="94"/>
        <source>Ctrl+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="94"/>
        <source>Unmirror the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="98"/>
        <source>Mirror &amp;Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="98"/>
        <source>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="98"/>
        <source>Horizontally mirror the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="105"/>
        <source>Mirror &amp;Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="105"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="105"/>
        <source>Vertically mirror the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="112"/>
        <source>&amp;About Image Changer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="131"/>
        <source>&amp;Help</source>
        <translation>&amp;Aide</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="117"/>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="123"/>
        <source>&amp;Edit</source>
        <translation>&amp;Edition</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="127"/>
        <source>&amp;Mirror</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="174"/>
        <source>Image Changer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="224"/>
        <source>Image Changer - Unsaved Changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="224"/>
        <source>Save unsaved changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="247"/>
        <source>Image Changer - %1[*]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="250"/>
        <source>Image Changer - Unnamed[*]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="252"/>
        <source>Image Changer[*]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="293"/>
        <source>Created new image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="303"/>
        <source>Image Changer - Choose Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="370"/>
        <source>Image files (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="323"/>
        <source>Failed to read %1</source>
        <translation>N&apos;a pas chargé %1</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="335"/>
        <source>Loaded %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="356"/>
        <source>Saved as %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="360"/>
        <source>Failed to save %1</source>
        <translation>N&apos;a pas sauvegardé %1</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="370"/>
        <source>Image Changer - Save Image</source>
        <translation>Image Changer -- Sauvegardé Fichiez</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="405"/>
        <source>Inverted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="405"/>
        <source>Uninverted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="415"/>
        <source>Swapped Red and Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="415"/>
        <source>Unswapped Red and Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="435"/>
        <source>Mirrored Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="435"/>
        <source>Unmirrored Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="446"/>
        <source>Mirrored Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="446"/>
        <source>Unmirrored Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="453"/>
        <source>Image Changer - Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="453"/>
        <source>Percent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="469"/>
        <source>Resized to the same size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="478"/>
        <source>Resized to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="494"/>
        <source>About Image Changer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="494"/>
        <source>&lt;b&gt;Image Changer&lt;/b&gt; v %1
                &lt;p&gt;Copyright &amp;copy; 2007 Qtrac Ltd. 
                All rights reserved.
                &lt;p&gt;This application can be used to perform
                simple image manipulations.
                &lt;p&gt;Python %2 - Qt %3 - PyQt %4 
                on %5</source>
        <translation type="unfinished">&lt;b&gt;Image Changer&lt;/b&gt; v %1
                &lt;p&gt;Copyright &amp;copy; 2007 Qtrac Ltd. 
                Tous droits réservés.
                &lt;p&gt;This application can be used to perform
                simple image manipulations.
                &lt;p&gt;Python %2 - Qt %3 - PyQt %4 
                on %5
<byte value="x9"/></translation>
    </message>
</context>
<context>
    <name>NewImageDlg</name>
    <message>
        <location filename="ui_newimagedlg.py" line="82"/>
        <source>Image Chooser - New Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_newimagedlg.py" line="83"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_newimagedlg.py" line="84"/>
        <source>&amp;Color...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_newimagedlg.py" line="85"/>
        <source>&amp;Brush pattern:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_newimagedlg.py" line="86"/>
        <source>&amp;Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_newimagedlg.py" line="87"/>
        <source>&amp;Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_newimagedlg.py" line="89"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Backward Diagonal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Forward Diagonal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Diagonal Cross</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResizeDlg</name>
    <message>
        <location filename="resizedlg.py" line="21"/>
        <source>&amp;Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resizedlg.py" line="27"/>
        <source>&amp;Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resizedlg.py" line="48"/>
        <source>Image Changer - Resize</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="imagechanger.pyw" line="527"/>
        <source>Image Changer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
